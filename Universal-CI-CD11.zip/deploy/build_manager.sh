#!/bin/bash
REPO_DIR=$(cat .current_repo)
cd "$REPO_DIR" || exit

if [[ -f "index.html" ]]; then
  echo "Detected static HTML project."
elif [[ -f "app.py" ]]; then
  echo "Detected Python project."
  pip install -r requirements.txt
elif [[ -f "pom.xml" ]]; then
  echo "Detected Java project."
  mvn clean package
else
  echo "Unknown project type."
fi
