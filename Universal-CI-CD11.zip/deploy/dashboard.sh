#!/bin/bash
REPO_DIR=$(cat .current_repo)
echo "==== DASHBOARD ===="
echo "📁 Repo: $REPO_DIR"
echo "🕒 Last Deployed: $(stat -c %y "$REPO_DIR")"
ps aux | grep -E 'python3 -m http.server|python3 app.py|java -jar'
