#!/bin/bash
REPO_DIR=$(cat .current_repo)
cd "$REPO_DIR" || exit

if [[ -f "index.html" ]]; then
  nohup python3 -m http.server 3000 > /dev/null 2>&1 &
elif [[ -f "app.py" ]]; then
  nohup python3 app.py > /dev/null 2>&1 &
elif [[ -f "target/*.jar" ]]; then
  nohup java -jar target/*.jar > /dev/null 2>&1 &
fi
