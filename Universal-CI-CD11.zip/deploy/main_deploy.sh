#!/bin/bash
echo "==== CI/CD: Universal Shell Deployer ===="
REPO_URL="$1"
if [[ -z "$REPO_URL" ]]; then
  echo "❌ No GitHub URL provided."
  exit 1
fi

cd "$(dirname "$0")/.." || exit
source .env

./deploy/git_manager.sh "$REPO_URL"
./deploy/build_manager.sh
./deploy/deploy_manager.sh
./deploy/cleanup_manager.sh
